import React from 'react';
import SongList from './SongList'
function App() {
  return (
    <div>
      <SongList/>
    </div>
  );
}

export default App;
