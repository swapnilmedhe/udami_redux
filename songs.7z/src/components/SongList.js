import React, { Component } from 'react';
import {connect} from 'react-redux';
import {selectSong} from '../actions/index'

class SongList extends Component {

    renderlist (){
         return this.props.songs.map( (songs) =>{
             return (
                 <div className="item" key={songs.title}>
                     <div className="right floated content">
                     <button className="ui button primary" onClick={() =>{this.props.selectSong(songs)}}>Select</button>
                     </div>

                     <div className="content ">
                          {songs.title}
                     </div>
                 </div>
             )
         })
    }
  render() {
    
    return (
      <div className="ui divided list">
      {this.renderlist()}
      </div>
    )
  }
}


const mapStateToprops = (state) =>
{
    console.log(state)
   return {songs:state.songs}
}
export default connect(mapStateToprops,{selectSong})(SongList)
