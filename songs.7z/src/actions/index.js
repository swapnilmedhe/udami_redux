
import React from 'react'
import { type } from 'os';

//anction creator
export const selectSong =(song) =>
{
    //return action
  return{
      type:"SONG_SELECTED",
      payload:song

  }
}


